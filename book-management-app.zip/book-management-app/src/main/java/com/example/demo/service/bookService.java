package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.bookEntity.Book;
import com.example.demo.repository.BookRepository;

@Service
public class bookService {
	
	@Autowired
	private BookRepository bookrep;
	
	
	public Optional<Book> getBookById(int id) {
		return bookrep.findById(id);
	}
	public Book saveBook(Book b) {
		return bookrep.save(b);
	}
	
	public List<Book> getAllBook() {
		return bookrep.findAll();
	}
	
	public Book updateBookById(Book b) {
		return bookrep.save(b);
	}
	
	public String deleteBookById(int id) {
		bookrep.deleteById(id);
		return "Deletion successful";
	}
}
