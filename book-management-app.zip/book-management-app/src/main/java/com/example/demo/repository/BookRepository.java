package com.example.demo.repository;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;

import com.example.demo.bookEntity.Book;

public interface BookRepository extends JpaRepositoryImplementation<Book, Integer>{
	
}
